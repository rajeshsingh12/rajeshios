//
//  product.swift
//  ContactApp
//
//  Created by Rahul Sinha on 10/05/20.
//  Copyright © 2020 CYFUTURE. All rights reserved.
//

import UIKit

class product {
    
    //MARK: Properties
    
    var name: String = ""
    var discription: String = ""
    var regprice: String = ""
    var saleprice: String = ""
    var sImage: UIImage?
    var colorsarray: [String] = []
    var storesdictionary = [String: String]()
    
}
