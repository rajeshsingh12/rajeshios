//
//  HomeViewController.swift
//  ContactApp
//
//  Created by Rahul Sinha on 10/05/20.
//  Copyright © 2020 CYFUTURE. All rights reserved.
//

import UIKit
import CoreData

class NewCustomCell: UITableViewCell {
    
    @IBOutlet weak var lablename : UILabel!
    @IBOutlet weak var labeldisc : UILabel!
    @IBOutlet weak var labelregprice : UILabel!
    @IBOutlet weak var labelsaleprice : UILabel!
    @IBOutlet weak var imageuser : UIImageView!
    
}
//let row
//let productdetailSegueIdentifier = "productdetail"
class HomeViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
var item :[Any] = []
var row:Int = 1
let appdelegate = UIApplication.shared.delegate as! AppDelegate
@IBOutlet weak var productlisttableview: UITableView!
@IBOutlet weak var productdetailview: UIView!
@IBOutlet weak var bigimagedetailview: UIView!
@IBOutlet weak var bigimagedetail: UIImageView!
@IBOutlet weak var namedetail: UITextField!
@IBOutlet weak var discriptiondetail: UITextField!
@IBOutlet weak var regularpricedetail: UITextField!
@IBOutlet weak var salepricedetail: UITextField!
@IBOutlet weak var imagedetail: UIImageView!
@IBOutlet weak var updatebtn: UIButton!
@IBOutlet weak var deletebtn: UIButton!
@IBOutlet weak var cutbtn: UIButton!
let imagePicker = UIImagePickerController()
    
  func delete(productitem : Product){
        
      Coredatamanager.sharedManager.delete(productitem: productitem)
        
    }
    

  func update(name:String, discription : String,regprice : String,saleprice : String,sImage : Data, productitem : Product) {
    Coredatamanager.sharedManager.update(name: name, discription: discription,regprice: regprice,saleprice: saleprice,sImage: sImage, productitem: productitem)
  }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
           productdetailview.isHidden = true
           bigimagedetailview.isHidden = true
           let context = Coredatamanager.sharedManager.persistentContainer.viewContext
           var locations = [Product]() // Login is your Entity name
           let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
           fetchRequest.returnsObjectsAsFaults = false
           locations = try! context.fetch(fetchRequest) as! [Product]
           for location in locations
           {
               item.append(location) // item is your array
           }
           
           self.productlisttableview.reloadData()
    }
    
    
    
     func numberOfSections(in tableView: UITableView) -> Int
        {
            
            return 1
            
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) ->
            Int
        {
            
            return item.count
            
        }
        
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) ->
            UITableViewCell
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for:
                indexPath) as! NewCustomCell // CustomCell is your Cell File name
            let dic = item[indexPath.row] as! NSManagedObject
             print("JsonResponsedict: ", dic)
           
            cell.lablename?.text = dic.value(forKey: "name" ) as? String
            cell.labeldisc?.text = dic.value(forKey: "discription" ) as? String
            cell.labelregprice?.text = dic.value(forKey: "regprice" ) as? String
            cell.labelsaleprice?.text = dic.value(forKey: "saleprice" ) as? String
            
            
            
            

            if dic.value(forKey: "sImage" ) as? Data == nil {
                
            }
            else
            {
              cell.imageuser?.image = UIImage (data: dic.value(forKey: "sImage" ) as! Data)
            }
            //cell.imageuse?.image = UIImage(named: "Apple")
            cell.imageuser?.layer.cornerRadius = 50
            return cell
        }
    
       func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
                row = indexPath.row
       //        //print(swiftBlogs[row])
       //  let indexPath = productlisttableview.indexPathForSelectedRow!
       

        let dic = item[indexPath.row] as! NSManagedObject
        
        print("JsonResponsedictnew: ", dic)
        
        productdetailview.isHidden = false
        
        namedetail.text = dic.value(forKey: "name" ) as? String
        discriptiondetail.text = dic.value(forKey: "discription" ) as? String
        regularpricedetail.text = dic.value(forKey: "regprice" ) as? String
        salepricedetail.text = dic.value(forKey: "saleprice" ) as? String
                 
                 
                 
                 

        if dic.value(forKey: "sImage" ) as? Data == nil {
                     
        }
        else
        {
          imagedetail.image = UIImage (data: dic.value(forKey: "sImage" ) as! Data)
        }
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        imagedetail.isUserInteractionEnabled = true
        imagedetail.addGestureRecognizer(tapGestureRecognizer)
        
    }
    
      @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
      {
        bigimagedetailview.isHidden = false
         //let tappedImage = tapGestureRecognizer.view as! UIImageView

          // Your action
        
        let imageData: NSData = self.imagedetail.image!.pngData()! as NSData
        
        bigimagedetail.image = UIImage (data: imageData as Data)
        
      }
    
    
    
    
    
     /*configure delete row*/
     @IBAction func deletecall(_ sender: UIButton) {
        
         
        let delcontext = Coredatamanager.sharedManager.persistentContainer.viewContext
        
       let commit = item[row]
        
        
        self.delete( productitem : (commit as? Product)! )
        
         item.remove(at: row)
        
        productdetailview.isHidden = true
        
            do {
               try delcontext.save()
             } catch {
               // Do something in response to error condition
             }
            /*Finally reload tableview*/
        self.productlisttableview.reloadData()
         
     }
    
    
   
    
    
    
    /*configure update row*/
    @IBAction func updatecall(_ sender: UIButton) {

            let commit = item[row]
            let nameToSave: String = namedetail.text!
            let discToSave: String = discriptiondetail.text!
            let regpriceToSave: String = regularpricedetail.text!
            let salepriceToSave: String = salepricedetail.text!
        
        
        
        let imageData: NSData = self.imagedetail.image!.pngData()! as NSData
        
        
        self.update(name: nameToSave, discription: discToSave,regprice: regpriceToSave,saleprice: salepriceToSave,sImage: imageData as Data, productitem : (commit as? Product)!)
        
        
            productdetailview.isHidden = true
            self.productlisttableview.reloadData()
              
          }
    
   
    

    /*configure hide detailview*/
    @IBAction func curbtncall(_ sender: UIButton) {
              
               productdetailview.isHidden = true
             
               
           }
    
    @IBAction func curimagebtncall(_ sender: UIButton) {
       
           bigimagedetailview.isHidden = true
      
        
    }
    
    @IBAction func editImagetap(_ sender: UIButton) {
            imagePicker.allowsEditing = false
            imagePicker.sourceType = .photoLibrary
            imagePicker.delegate = self
            present(imagePicker, animated: true, completion: nil)
        }
        
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                imagedetail.contentMode = .scaleToFill
                imagedetail.image = pickedImage
            }
            
            dismiss(animated: true, completion: nil)
        }
        
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true, completion: nil)
        }
    
}

