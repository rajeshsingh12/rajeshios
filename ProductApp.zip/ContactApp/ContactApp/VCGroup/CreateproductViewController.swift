//
//  CreateproductViewController.swift
//  ContactApp
//
//  Created by Rahul Sinha on 10/05/20.
//  Copyright © 2020 CYFUTURE. All rights reserved.
//

import UIKit
import CoreData
class CreateproductViewController: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
@IBOutlet weak var productname: UITextField!
@IBOutlet weak var productdiscription: UITextField!
@IBOutlet weak var productregularprice: UITextField!
@IBOutlet weak var productsaleprice: UITextField!
@IBOutlet weak var productimage: UIImageView!

let imagePicker = UIImagePickerController()


let nscontext = Coredatamanager.sharedManager.persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // productimage.layer.cornerRadius = 30
        // Do any additional setup after loading the view.
    }
    
  
    
    
    @IBAction func loadImagetap(_ sender: UIButton) {
         imagePicker.allowsEditing = false
         imagePicker.sourceType = .photoLibrary
         imagePicker.delegate = self
         present(imagePicker, animated: true, completion: nil)
     }
     
     
     func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
         if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
             productimage.contentMode = .scaleToFill
             productimage.image = pickedImage
         }
         
         dismiss(animated: true, completion: nil)
     }
     
     
     func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
         dismiss(animated: true, completion: nil)
     }
    
      @IBAction func Add(_ sender: Any)
         {
             if productname.text == "" {
                 let alertController = UIAlertController(title: "Alert", message: "Please fill Name Field", preferredStyle: .alert)
                 let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                 alertController.addAction(defaultAction)
                 
                 present(alertController, animated: true, completion: nil)
             }
             else
             {
                 
             
                     
                   
                         let entity = NSEntityDescription.insertNewObject(forEntityName: "Product", into: nscontext)
                         
                        
                         
                       
                         entity.setValue(productname.text, forKey: "name")
                         entity.setValue(productdiscription.text, forKey: "discription")
                         entity.setValue(productregularprice.text, forKey: "regprice")
                         entity.setValue(productsaleprice.text, forKey: "saleprice")
                         
                         
                 
                         
                         
                         
                         
                      //  let img = UIImage(named: "Screenshot 2019-06-14 at 2.02.57 PM.png")
                         
     //                    let data = img.data(using: .utf8)
                        // let newImageData = UIImage(named: "Screenshot 2019-06-14 at 2.02.57 PM.png")
                  
                         let imageData: NSData = self.productimage.image!.pngData()! as NSData
                         
                         
                         
                        // options.setValue(id, forKey: "index")
                         entity.setValue(imageData, forKey: "sImage")

                         do{
                             try nscontext.save()
                             productname.text = ""
                             productdiscription.text = ""
                             productregularprice.text = ""
                             productsaleprice.text = ""
                             //productimage.image =
                         }
                         catch{
                             
                         }
                         print("Record Inserted")
                         // self.navigationController?.popViewController(animated: true)
                 }
         }
         
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
