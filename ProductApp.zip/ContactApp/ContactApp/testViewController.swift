//
//  testViewController.swift
//  ContactApp
//
//  Created by Rahul Sinha on 28/08/19.
//  Copyright © 2019 CYFUTURE. All rights reserved.
//

import UIKit


class testViewController: UIViewController {

//    var shoppinglist = ["catfish","water","tulips","blue paint",]
//
//   // shoppinglist[1] = "bottle of water"
//
//    var occupations = [
//        "Malcom": "Captain",
//        "Kaylee": "Mechanic"
//    ]
//
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        let individualScores = [75, 43, 103, 87, 12]
//        var teamScore = 0
//        for score in individualScores
//         {
//            if score > 50 {
//
//               teamScore += 3
//
//            } else {
//
//               print("yellow")
//
//            }
//        }
//
//        var optionalString: String? = "Hello"
//
//        optionalString = nil
//
//        let optionalName: String? = "john Appleseed"
//
//        var greeting  = "Hello!"
//
//
//
//        if let name = optionalName {
//            greeting = "Hello, \(name)"
//        }
//
//
//        let intrestingNumbers =
//        [
//            "Prime" : [2, 3, 5, 7, 11,13],"Fibonacci": [1, 1, 2, 3, 5, 8],"Square": [1, 4, 9, 16,25],
//        ]
//
//        var largest = 0
//
//
        
        // Do any additional setup after loading the view.
        
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
