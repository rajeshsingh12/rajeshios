//
//  Product+CoreDataClass.swift
//  
//
//  Created by Rahul Sinha on 10/05/20.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
