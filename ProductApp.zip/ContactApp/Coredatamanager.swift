//
//  Coredatamanager.swift
//  ContactApp
//
//  Created by Rahul Sinha on 11/05/20.
//  Copyright © 2020 CYFUTURE. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class Coredatamanager {
  
  //1
  static let sharedManager = Coredatamanager()
  private init() {} // Prevent clients from creating another instance.
  
  //2
  lazy var persistentContainer: NSPersistentContainer = {
    
    let container = NSPersistentContainer(name: "ContactApp")
    
    
    container.loadPersistentStores(completionHandler: { (storeDescription, error) in
      
      if let error = error as NSError? {
        fatalError("Unresolved error \(error), \(error.userInfo)")
      }
    })
    return container
  }()
  
  //3
  func saveContext () {
    let context = Coredatamanager.sharedManager.persistentContainer.viewContext
    if context.hasChanges {
      do {
        try context.save()
      } catch {
        // Replace this implementation with code to handle the error appropriately.
        // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        let nserror = error as NSError
        fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
      }
    }
  }
  

  
  func update(name:String, discription : String, regprice : String,saleprice : String,sImage : Data, productitem : Product) {
    
    /*1.
     Before you can save or retrieve anything from your Core Data store, you first need to get your hands on an NSManagedObjectContext. You can consider a managed object context as an in-memory “scratchpad” for working with managed objects.
     Think of saving a new managed object to Core Data as a two-step process: first, you insert a new managed object into a managed object context; then, after you’re happy with your shiny new managed object, you “commit” the changes in your managed object context to save it to disk.
     Xcode has already generated a managed object context as part of the new project’s template. Remember, this only happens if you check the Use Core Data checkbox at the beginning. This default managed object context lives as a property of the NSPersistentContainer in the application delegate. To access it, you first get a reference to the app delegate.
     */
    let context = Coredatamanager.sharedManager.persistentContainer.viewContext
    
    do {
      
      
      /*
       With an NSManagedObject in hand, you set the name attribute using key-value coding. You must spell the KVC key (name in this case) exactly as it appears in your Data Model
       */
      productitem.setValue(name, forKey: "name")
      productitem.setValue(discription, forKey: "discription")
      productitem.setValue(regprice, forKey: "regprice")
      productitem.setValue(regprice, forKey: "saleprice")
        
        //let imageData: NSData = image.pngData() as! NSData
         
         
         
        // options.setValue(id, forKey: "index")
        productitem.setValue(sImage, forKey: "sImage")
        
      
        //print("\(productitem.value(forKey: "name"))")
        //print("\(productitem.value(forKey: "ssn"))")
      
      /*
       You commit your changes to person and save to disk by calling save on the managed object context. Note save can throw an error, which is why you call it using the try keyword within a do-catch block. Finally, insert the new managed object into the people array so it shows up when the table view reloads.
       */
      do {
        try context.save()
        print("saved!")
      } catch let error as NSError  {
        print("Could not save \(error), \(error.userInfo)")
      } catch {
        
      }
      
    } catch {
      print("Error with request: \(error)")
    }
  }
  
  /*delete*/
    func delete(productitem : Product){
    
    let managedContext = Coredatamanager.sharedManager.persistentContainer.viewContext
    
    do {
      
        managedContext.delete(productitem)
      
    } catch {
      // Do something in response to error condition
      print(error)
    }
    
    do {
      try managedContext.save()
    } catch {
      // Do something in response to error condition
    }
  }
}

