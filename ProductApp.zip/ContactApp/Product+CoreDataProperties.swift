//
//  Product+CoreDataProperties.swift
//  
//
//  Created by Rahul Sinha on 10/05/20.
//
//

import Foundation
import CoreData


extension Product {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Product> {
        return NSFetchRequest<Product>(entityName: "Product")
    }

    @NSManaged public var discription: String?
    @NSManaged public var name: String?
    @NSManaged public var regprice: String?
    @NSManaged public var saleprice: String?
    @NSManaged public var sImage: Data?
    
    
  

}
